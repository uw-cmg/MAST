# creates lmp_atoms lmp_opls lmp_in

execfile('write_lammps.py')
