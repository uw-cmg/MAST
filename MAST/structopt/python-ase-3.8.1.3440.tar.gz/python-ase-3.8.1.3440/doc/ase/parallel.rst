.. module:: parallel

=====================
Parallel calculations
=====================

.. autofunction:: ase.parallel.paropen

.. autofunction:: ase.parallel.parprint
