.. module:: castep

========
CASTEP
========



.. include:: ../../../ase/calculators/castep.py
   :encoding: utf-8
   :start-after: CASTEP Interface Documentation
   :end-before: End CASTEP Interface Documentation


Example:
========

.. literalinclude:: ase_castep_demo.py
