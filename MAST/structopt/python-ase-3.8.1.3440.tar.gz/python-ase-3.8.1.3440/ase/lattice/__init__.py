from ase.lattice.bulk import bulk
