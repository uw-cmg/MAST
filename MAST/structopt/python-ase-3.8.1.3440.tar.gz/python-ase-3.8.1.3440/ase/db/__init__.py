from ase.db.core import connect


class IdCollisionError(Exception):
    pass
